console.log('Content script loaded'); // Debug statement

document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('a').forEach(function(link) {
        link.addEventListener('click', function() {
            console.log('Link clicked:', link.href); // Debug statement
            chrome.runtime.sendMessage({ type: 'trackLink', url: link.href });
        });
    });

    // Listen for dynamically added links
    new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            mutation.addedNodes.forEach(function(node) {
                if (node.tagName === 'A') {
                    console.log('Dynamically added link:', node.href); // Debug statement
                    node.addEventListener('click', function() {
                        chrome.runtime.sendMessage({ type: 'trackLink', url: node.href });
                    });
                }
            });
        });
    }).observe(document.body, { childList: true, subtree: true });
});