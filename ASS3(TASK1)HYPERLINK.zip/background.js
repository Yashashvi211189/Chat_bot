// background.js
let linksData = {};

chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  console.log('Message received in background:', message); // Debug statement
  if (message.type === 'trackLink') {
    const { url } = message;
    if (!linksData[url]) {
      linksData[url] = 0;
    }
    linksData[url]++;
    chrome.storage.local.set({ 'linksData': linksData }, function() {
      console.log('Data saved to storage:', linksData); // Debug statement
    });
  }
});
