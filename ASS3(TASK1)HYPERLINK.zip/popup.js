// popup.js
console.log('Popup loaded'); // Debug statement

document.addEventListener('DOMContentLoaded', function() {
    chrome.storage.local.get('linksData', function(result) {
        const linksData = result.linksData || {};
        const statsDiv = document.getElementById('stats');
        statsDiv.innerHTML = '<h3>Visited Sites Hyperlinks Occurrences</h3>';
        Object.keys(linksData).forEach(function(url) {
            statsDiv.innerHTML += `<p>${url} ${linksData[url]}</p>`;
        });
        console.log('Data loaded from storage:', linksData); // Debug statement
        });
        document.getElementById('showDetails').addEventListener('click', function() {
            console.log('Show details clicked'); // Debug statement
            chrome.tabs.create({ url: chrome.runtime.getURL('details.html') });
        });
    });
