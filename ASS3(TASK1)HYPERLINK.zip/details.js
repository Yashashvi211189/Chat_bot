document.addEventListener('DOMContentLoaded', function() {
    // Function to display the links in the table
    function displayLinks(linksData, filterDomain = '') {
        const tableBody = document.getElementById('linksTableBody');
      tableBody.innerHTML = ''; // Clear the table before populating

        Object.keys(linksData).forEach(function(url) {
        if (filterDomain && !url.includes(filterDomain)) {
          return; // Skip if the URL does not match the filter domain
        }

        const row = tableBody.insertRow();
        const cellSite = row.insertCell(0);
        const cellLink = row.insertCell(1);
        const cellOccurrences = row.insertCell(2);

        const urlObj = new URL(url);
        cellSite.textContent = urlObj.hostname;
        cellLink.textContent = url;
        cellOccurrences.textContent = linksData[url];
});
}
    // Load data from storage and display it in the table
    chrome.storage.local.get('linksData', function(result) {
        const linksData = result.linksData || {};
        displayLinks(linksData);
      console.log('Detailed data loaded from storage:', linksData); // Debug statement
    });
    // Filter button click event
    document.getElementById('filterButton').addEventListener('click', function() {
        const filterDomain = document.getElementById('filterInput').value.trim();
        chrome.storage.local.get('linksData', function(result) {
            const linksData = result.linksData || {};
            displayLinks(linksData, filterDomain);
    });
});
});
